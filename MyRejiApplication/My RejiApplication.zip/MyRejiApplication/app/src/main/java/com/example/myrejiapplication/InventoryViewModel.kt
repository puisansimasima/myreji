package com.example.myrejiapplication

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.widget.Adapter
import androidx.lifecycle.LiveData
import androidx.lifecycle.asLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.myrejiapplication.data.ItemDao
import com.example.myrejiapplication.data.Item
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch


class InventoryViewModel(private val itemDao: ItemDao) : ViewModel() {

    // Cache all items form the database using LiveData.
    val viewList:Flow<List<Item>> = itemDao.getAll()

    val allItems: LiveData<List<Item>> = itemDao.getAll().asLiveData()

    lateinit var flatList: List<Item>


    private fun insertItem(item: Item) {
        viewModelScope.launch {
            itemDao.insert(item)
        }
    }

    fun getItem(itemId: Int){

    }


    fun deleteItem(item: Item) {

        viewModelScope.launch {
            itemDao.delete(item)
        }
    }

    //fun deleteDatabaseItem()


    private fun getNewItemEntry(itemId:Int,itemName: String, itemPrice: String, categoryName: String): Item {
        return Item(
            id=itemId,
            itemName = itemName,
            itemPrice = itemPrice.toDouble(),
            categoryName = categoryName
        )
    }

    fun addNewItem(itemId: Int,  itemName: String, itemPrice: String, categoryName: String) {
        val newItem = getNewItemEntry(itemId, itemName, itemPrice, categoryName)
        insertItem(newItem)

        Log.d("TAG", "addNewItem(u,,)")
    }

    fun isEntryValid(itemName: String, itemPrice: String, categoryName: String): Boolean {
        if (itemName.isBlank()|| itemPrice.isBlank() || categoryName.isBlank()) {
            return false
        }
        return true
    }



    fun makeFlatList(){
        viewModelScope.launch {

            val flowOfLists: Flow<List<Item>> = viewList
            flatList= flowOfLists.flattenToList()

        }


    }

}

    class InventoryViewModelFactory(private val itemDao: ItemDao) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(InventoryViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return InventoryViewModel(itemDao) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")

        }





    }


suspend fun <T> Flow<List<T>>.flattenToList() =
    flatMapConcat { it.asFlow() }.toList()



